import javax.swing.JFrame;
public class RadioButtonTest {

        public static void main(String[] args) {
                RadioButtonFrame panel = new RadioButtonFrame();

                panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                panel.setSize(300, 100);
                panel.setVisible(true);
        }
}