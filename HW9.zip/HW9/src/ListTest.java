import javax.swing.JFrame;
public class ListTest {
        
        public static void main(String[] args) {
                
                ListFrame panel = new ListFrame();

                panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                panel.setSize(350, 150);
                panel.setVisible(true);

        }

}
