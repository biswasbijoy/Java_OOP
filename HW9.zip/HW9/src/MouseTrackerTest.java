import javax.swing.JFrame;
public class MouseTrackerTest {
        
        public static void main(String[] args) {
                
                MouseTrackerFrame panel = new MouseTrackerFrame();

                panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                panel.setSize(300, 100);
                panel.setVisible(true);

        }

}
