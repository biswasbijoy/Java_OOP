import javax.swing.JFrame;
public class CheckBoxTest {

        public static void main(String[] args) {
                CheckBoxFrame panel = new CheckBoxFrame();

                panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                panel.setSize(275, 100);
                panel.setVisible(true);
        }
        
}
