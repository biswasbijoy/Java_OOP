import javax.swing.JFrame;
public class TextAreaDemo {
        public static void main(String[] args) {
                TextAreaFrame panel = new TextAreaFrame();
                panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                panel.setSize(425, 200);
                panel.setVisible(true);
        }
}