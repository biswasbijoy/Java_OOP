import javax.swing.JFrame;
public class MultipleSelectionTest {
        
        public static void main(String[] args) {
                
                MultipleSelectionFrame panel = new MultipleSelectionFrame();

                panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                panel.setSize(350, 150);
                panel.setVisible(true);

        }

}
