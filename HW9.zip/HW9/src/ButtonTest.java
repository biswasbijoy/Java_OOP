import javax.swing.JFrame;
public class ButtonTest {
        
        public static void main(String[] args) {
                
                ButtonFrame panel = new ButtonFrame();
                panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                panel.setSize(290, 110);
                panel.setVisible(true);
                
        }

}
