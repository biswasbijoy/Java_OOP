import javax.swing.JFrame;
public class ComboBoxTest {

        public static void main(String[] args) {
                ComboBoxFrame panel = new ComboBoxFrame();

                panel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                panel.setSize(350, 150);
                panel.setVisible(true);
        }
}