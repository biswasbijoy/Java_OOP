import javax.swing.JFrame;

public class KeyDemo {
        
        public static void main(String[] args) {
                
                KeyDemoFrame labelFrame = new KeyDemoFrame();

                // JFrame app = new JFrame();
                

                labelFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                labelFrame.setSize(260, 180);
                labelFrame.setVisible(true);
                

        }

}
